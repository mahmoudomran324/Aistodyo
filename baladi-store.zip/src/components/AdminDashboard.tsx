import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import {
  User,
  SupervisorPermissions,
  Product,
  ProductCategory,
  Ad,
  OrderStatus
} from '../types';
import {
  LayoutDashboard,
  Users,
  Store,
  ShieldAlert,
  Percent,
  DollarSign,
  Package,
  Megaphone,
  Settings,
  UserCheck,
  UserX,
  FileText,
  KeyRound,
  Plus,
  Trash2,
  Edit,
  Eye,
  EyeOff,
  CheckCircle2,
  X,
  Upload,
  MessageCircle,
  Smartphone,
  Bike,
  AlertTriangle,
  RotateCcw,
  Search,
  Filter
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    currentUser,
    users,
    orders,
    products,
    transactions,
    ads,
    settings,
    resetRequests,
    banTrader,
    unbanTrader,
    zeroTraderDebt,
    banCustomer,
    unbanCustomer,
    deleteUser,
    addOrUpdateUser,
    updateOrderStatus,
    addProduct,
    updateProduct,
    deleteProduct,
    toggleHideProduct,
    addAd,
    updateAd,
    deleteAd,
    updateSettings,
    resolvePasswordReset
  } = useStore();

  const [activeTab, setActiveTab] = useState<
    'overview' | 'orders' | 'products' | 'traders' | 'supervisors' | 'customers' | 'ads' | 'resets' | 'settings'
  >('overview');

  // Trader Ban Modal State
  const [banModalTrader, setBanModalTrader] = useState<User | null>(null);
  const [banReason, setBanReason] = useState('التأخر في سداد المديونية المستحقة للمنصة أو شكاوى جودة');
  const [banResolutionSteps, setBanResolutionSteps] = useState(
    '1. مراجعة كشف الحساب وسداد المبلغ عبر إنستاباي أو فودافون كاش.\n2. إرسال إيصال السداد للدعم الفني لرفع الحظر فوراً.'
  );
  const [banWhatsAppLink, setBanWhatsAppLink] = useState('');

  // Comprehensive Product & Agreed Deals State for Admin & Supervisor
  const [isProdModalOpen, setIsProdModalOpen] = useState(false);
  const [editingProd, setEditingProd] = useState<Product | null>(null);
  const [prodTraderId, setProdTraderId] = useState('');
  const [prodName, setProdName] = useState('');
  const [prodCategory, setProdCategory] = useState<ProductCategory>('vegetables');
  const [prodPrice, setProdPrice] = useState<number>(25);
  const [prodUnit, setProdUnit] = useState<string>('كجم');
  const [prodStock, setProdStock] = useState<number>(50);
  const [prodImage, setProdImage] = useState<string>('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodBadge, setProdBadge] = useState('فرز أول');
  const [prodHasOffer, setProdHasOffer] = useState(false);
  const [prodDiscountPrice, setProdDiscountPrice] = useState<number | undefined>(undefined);
  const [prodOfferBadge, setProdOfferBadge] = useState('عرض خاص بالاتفاق مع التاجر');

  // Quick Deal Modal State
  const [dealModalProduct, setDealModalProduct] = useState<Product | null>(null);
  const [quickDealDiscount, setQuickDealDiscount] = useState<number>(20);
  const [quickDealBadge, setQuickDealBadge] = useState('عرض خاص بالاتفاق مع التاجر');

  // Filters for Products Tab
  const [prodFilterSearch, setProdFilterSearch] = useState('');
  const [prodFilterTrader, setProdFilterTrader] = useState('all');
  const [prodFilterCategory, setProdFilterCategory] = useState('all');
  const [prodFilterOffersOnly, setProdFilterOffersOnly] = useState(false);

  // Add Trader Product Modal (Admin can add products to any trader)
  const [traderProdModalTrader, setTraderProdModalTrader] = useState<User | null>(null);
  const [newProdName, setNewProdName] = useState('');
  const [newProdCategory, setNewProdCategory] = useState<ProductCategory>('vegetables');
  const [newProdPrice, setNewProdPrice] = useState<number>(20);
  const [newProdUnit, setNewProdUnit] = useState<string>('كجم');
  const [newProdStock, setNewProdStock] = useState<number>(50);
  const [newProdImage, setNewProdImage] = useState<string>('');
  const [newProdDesc, setNewProdDesc] = useState('');

  // Supervisor Form Modal
  const [isSupervisorModalOpen, setIsSupervisorModalOpen] = useState(false);
  const [editingSupervisor, setEditingSupervisor] = useState<User | null>(null);
  const [supName, setSupName] = useState('');
  const [supEmail, setSupEmail] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supPassword, setSupPassword] = useState('Password123');
  const [supTitle, setSupTitle] = useState('مشرف رقابة وجودة المنتجات');
  const [supPermissions, setSupPermissions] = useState<SupervisorPermissions>({
    canManageOrders: true,
    canManageProducts: true,
    canManageTraders: true,
    canManageCustomers: true,
    canManageDebts: false,
    canManageAds: true,
    canHandleResets: true,
    canViewReports: true
  });

  // Ads Form Modal
  const [isAdModalOpen, setIsAdModalOpen] = useState(false);
  const [adTitle, setAdTitle] = useState('');
  const [adDescription, setAdDescription] = useState('');
  const [adBadge, setAdBadge] = useState('عرض مميز');
  const [adTargetCategory, setAdTargetCategory] = useState<ProductCategory | 'all'>('all');
  const [adImage, setAdImage] = useState('');
  const [adStartDate, setAdStartDate] = useState('2026-01-01');
  const [adEndDate, setAdEndDate] = useState('2026-12-31');

  // User Add/Edit modal (for direct manual registration of customer/trader)
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [uName, setUName] = useState('');
  const [uPhone, setUPhone] = useState('');
  const [uEmail, setUEmail] = useState('');
  const [uPassword, setUPassword] = useState('123456');
  const [uRole, setURole] = useState<'customer' | 'trader'>('customer');
  const [uStoreName, setUStoreName] = useState('');

  // Settings inputs
  const [setStoreName, setSetStoreName] = useState(settings.storeName);
  const [setStoreSubtitle, setSetStoreSubtitle] = useState(settings.storeSubtitle);
  const [setInstapay, setSetInstapay] = useState(settings.instapayAccount);
  const [setVodafone, setSetVodafone] = useState(settings.vodafoneCashNumber);
  const [setDeliveryFee, setSetDeliveryFee] = useState(settings.deliveryFee);
  const [setCommissionRate, setSetCommissionRate] = useState(settings.platformCommissionRate);
  const [setCaptainEnabled, setSetCaptainEnabled] = useState(settings.isCaptainSystemEnabled);
  const [setWhatsApp, setSetWhatsApp] = useState(settings.supportWhatsApp);
  const [settingsSaveMsg, setSettingsSaveMsg] = useState('');

  // Filtering
  const [traderSearch, setTraderSearch] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');

  // Calculations
  const allTraders = users.filter(u => u.role === 'trader');
  const allSupervisors = users.filter(u => u.role === 'supervisor');
  const allCustomers = users.filter(u => u.role === 'customer');

  const totalStoreSales = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.subtotal, 0);

  const totalPlatformCommissions = (totalStoreSales * settings.platformCommissionRate) / 100;
  const totalTradersDebt = allTraders.reduce((sum, t) => sum + (t.debt || 0), 0);

  // Check supervisor permissions if current user is supervisor
  const isSupervisor = currentUser?.role === 'supervisor';
  const supervisorPerms = currentUser?.supervisorPermissions;

  const canEditTraders = !isSupervisor || supervisorPerms?.canManageTraders;
  const canEditProducts = !isSupervisor || supervisorPerms?.canManageProducts;
  const canEditOrders = !isSupervisor || supervisorPerms?.canManageOrders;
  const canEditDebts = !isSupervisor || supervisorPerms?.canManageDebts;
  const canEditAds = !isSupervisor || supervisorPerms?.canManageAds;
  const canHandleResets = !isSupervisor || supervisorPerms?.canHandleResets;

  // Handle Trader Ban action
  const handleConfirmBanTrader = (e: React.FormEvent) => {
    e.preventDefault();
    if (!banModalTrader) return;

    const link = banTrader(banModalTrader.id, banReason.trim(), banResolutionSteps.trim());
    setBanWhatsAppLink(link);
  };

  // Image Upload helper
  const handleUploadImageFile = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setter(reader.result);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Save Settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      storeName: setStoreName.trim(),
      storeSubtitle: setStoreSubtitle.trim(),
      instapayAccount: setInstapay.trim(),
      vodafoneCashNumber: setVodafone.trim(),
      deliveryFee: Number(setDeliveryFee),
      platformCommissionRate: Number(setCommissionRate),
      isCaptainSystemEnabled: setCaptainEnabled,
      supportWhatsApp: setWhatsApp.trim()
    });

    setSettingsSaveMsg('تم حفظ وتحديث إعدادات المنصة بنجاح!');
    setTimeout(() => setSettingsSaveMsg(''), 3000);
  };

  // Save Supervisor
  const handleSaveSupervisor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supName.trim() || !supEmail.trim()) return;

    if (editingSupervisor) {
      addOrUpdateUser({
        ...editingSupervisor,
        name: supName.trim(),
        email: supEmail.trim().toLowerCase(),
        phone: supPhone.trim(),
        password: supPassword.trim(),
        supervisorTitle: supTitle.trim(),
        supervisorPermissions: supPermissions
      });
    } else {
      addOrUpdateUser({
        name: supName.trim(),
        email: supEmail.trim().toLowerCase(),
        phone: supPhone.trim(),
        password: supPassword.trim(),
        role: 'supervisor',
        supervisorTitle: supTitle.trim(),
        supervisorPermissions: supPermissions
      });
    }

    setIsSupervisorModalOpen(false);
  };

  // Save Ad
  const handleSaveAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adTitle.trim() || !adImage) return;

    addAd({
      title: adTitle.trim(),
      description: adDescription.trim(),
      badgeText: adBadge.trim(),
      targetCategory: adTargetCategory,
      image: adImage,
      startDate: adStartDate,
      endDate: adEndDate,
      isActive: true,
      linkText: 'تسوق الآن'
    });

    setIsAdModalOpen(false);
  };

  // Save Product by Admin for a Trader
  const handleSaveAdminProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!traderProdModalTrader || !newProdName.trim() || !newProdImage) return;

    addProduct({
      name: newProdName.trim(),
      category: newProdCategory,
      price: Number(newProdPrice),
      unit: newProdUnit.trim(),
      stock: Number(newProdStock),
      image: newProdImage,
      traderId: traderProdModalTrader.id,
      traderName: traderProdModalTrader.storeName || traderProdModalTrader.name,
      isHidden: false,
      description: newProdDesc.trim() || 'صنف ممتاز مضاف بمعرفة الإدارة.',
      freshnessBadge: 'فرز أول'
    });

    setTraderProdModalTrader(null);
  };

  // Open Add Product Modal
  const handleOpenAddProduct = (defaultTraderId?: string) => {
    setEditingProd(null);
    setProdTraderId(defaultTraderId || allTraders[0]?.id || 'usr_trader_1');
    setProdName('');
    setProdCategory('vegetables');
    setProdPrice(25);
    setProdUnit('كجم');
    setProdStock(50);
    setProdImage('https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80');
    setProdDesc('');
    setProdBadge('فرز أول');
    setProdHasOffer(false);
    setProdDiscountPrice(undefined);
    setProdOfferBadge('عرض خاص بالاتفاق مع التاجر');
    setIsProdModalOpen(true);
  };

  // Open Edit Product Modal
  const handleOpenEditProduct = (prod: Product) => {
    setEditingProd(prod);
    setProdTraderId(prod.traderId);
    setProdName(prod.name);
    setProdCategory(prod.category);
    setProdPrice(prod.price);
    setProdUnit(prod.unit);
    setProdStock(prod.stock);
    setProdImage(prod.image);
    setProdDesc(prod.description);
    setProdBadge(prod.freshnessBadge || 'فرز أول');
    setProdHasOffer(Boolean(prod.discountPrice && prod.discountPrice < prod.price));
    setProdDiscountPrice(prod.discountPrice);
    setProdOfferBadge(prod.freshnessBadge || 'عرض خاص بالاتفاق مع التاجر');
    setIsProdModalOpen(true);
  };

  // Save Product (Add or Edit) with Agreed Deals
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName.trim() || !prodImage) return;

    const selectedTrader = allTraders.find(t => t.id === prodTraderId);
    const traderName = selectedTrader?.storeName || selectedTrader?.name || 'مزرعة بلدي المعتمدة';
    const discountVal = prodHasOffer && prodDiscountPrice ? Number(prodDiscountPrice) : undefined;
    const finalBadge = prodHasOffer ? prodOfferBadge.trim() || 'عرض خاص بالاتفاق مع التاجر' : prodBadge.trim();

    if (editingProd) {
      updateProduct(editingProd.id, {
        traderId: prodTraderId,
        traderName,
        name: prodName.trim(),
        category: prodCategory,
        price: Number(prodPrice),
        discountPrice: discountVal,
        unit: prodUnit.trim(),
        stock: Number(prodStock),
        image: prodImage,
        description: prodDesc.trim(),
        freshnessBadge: finalBadge
      });
    } else {
      addProduct({
        traderId: prodTraderId,
        traderName,
        name: prodName.trim(),
        category: prodCategory,
        price: Number(prodPrice),
        discountPrice: discountVal,
        unit: prodUnit.trim(),
        stock: Number(prodStock),
        image: prodImage,
        isHidden: false,
        description: prodDesc.trim() || 'صنف بلدي فرز أول طازج وعالي الجودة.',
        freshnessBadge: finalBadge
      });
    }

    setIsProdModalOpen(false);
  };

  // Quick Deal Agreement Save
  const handleSaveQuickDeal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dealModalProduct) return;
    updateProduct(dealModalProduct.id, {
      discountPrice: Number(quickDealDiscount),
      freshnessBadge: quickDealBadge.trim() || 'عرض خاص بالاتفاق مع التاجر'
    });
    setDealModalProduct(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900 text-white rounded-3xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-600 text-white rounded-2xl shadow-md">
            <LayoutDashboard className="w-7 h-7" />
          </div>
          <div>
            <span className="bg-white/10 text-emerald-300 text-[11px] px-2.5 py-0.5 rounded-full font-bold">
              لوحة الإدارة المركزية الشاملة
            </span>
            <h1 className="text-xl md:text-2xl font-black mt-1">
              إدارة {settings.storeName}
            </h1>
            <p className="text-stone-400 text-xs mt-0.5">
              المستخدم الحالي: <strong>{currentUser?.name}</strong> ({currentUser?.role === 'admin' ? 'مدير عام النظام' : currentUser?.supervisorTitle})
            </p>
          </div>
        </div>

        {/* Quick Toggles */}
        <div className="flex items-center gap-2">
          {currentUser?.role === 'admin' && (
            <div className="bg-stone-800/80 px-3.5 py-2 rounded-2xl border border-stone-700 flex items-center gap-2 text-xs">
              <Bike className="w-4 h-4 text-blue-400" />
              <span>واجهة الكابتن:</span>
              <button
                onClick={() => {
                  updateSettings({ isCaptainSystemEnabled: !settings.isCaptainSystemEnabled });
                  setSetCaptainEnabled(!settings.isCaptainSystemEnabled);
                }}
                className={`px-2.5 py-0.5 rounded-lg font-bold transition cursor-pointer ${
                  settings.isCaptainSystemEnabled
                    ? 'bg-blue-600 text-white'
                    : 'bg-stone-700 text-stone-300'
                }`}
              >
                {settings.isCaptainSystemEnabled ? 'مفعلة وتظهر بالمتجر' : 'مخفية (افتراضي)'}
              </button>
            </div>
          )}

          <a
            href="./baladi-store.zip"
            download="baladi-store.zip"
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
            title="تحميل ملفات الموقع كاملة (ZIP) لرفعها على أي استضافة خارجية"
          >
            <Upload className="w-4 h-4 rotate-180" />
            <span>تحميل ملفات الموقع (ZIP)</span>
          </a>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="bg-white p-2 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap gap-1.5 text-xs md:text-sm font-bold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'overview' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <LayoutDashboard className="w-4 h-4" />
          <span>نظرة عامة</span>
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'orders' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>كل الطلبات ({orders.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'products' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>المنتجات والعروض ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('traders')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'traders' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Store className="w-4 h-4" />
          <span>التجار والمديونيات ({allTraders.length})</span>
        </button>

        {currentUser?.role === 'admin' && (
          <button
            onClick={() => setActiveTab('supervisors')}
            className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
              activeTab === 'supervisors' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>المشرفين والصلاحيات ({allSupervisors.length})</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('customers')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'customers' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <UserCheck className="w-4 h-4" />
          <span>العملاء ({allCustomers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('ads')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'ads' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>إعلانات المتجر ({ads.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('resets')}
          className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
            activeTab === 'resets' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
          }`}
        >
          <KeyRound className="w-4 h-4" />
          <span>طلبات نسيت كلمة السر ({resetRequests.filter(r => r.status === 'pending').length})</span>
        </button>

        {currentUser?.role === 'admin' && (
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 ${
              activeTab === 'settings' ? 'bg-emerald-700 text-white shadow-xs' : 'text-stone-600 hover:bg-stone-100'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>إعدادات النظام والرسائل</span>
          </button>
        )}
      </div>

      {/* ================= TAB 1: OVERVIEW ================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs text-stone-400 block font-semibold">إجمالي مبيعات المتجر</span>
              <span className="text-2xl font-black text-emerald-700">{totalStoreSales} جنيه</span>
              <p className="text-[11px] text-stone-400 mt-1">كل الأصناف المباعة</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs text-stone-400 block font-semibold">أرباح عمولات المنصة</span>
              <span className="text-2xl font-black text-purple-700">
                {totalPlatformCommissions.toFixed(1)} جنيه
              </span>
              <p className="text-[11px] text-stone-400 mt-1">نسبة {settings.platformCommissionRate}%</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs text-stone-400 block font-semibold">مديونيات التجار المستحقة</span>
              <span className="text-2xl font-black text-red-600">{totalTradersDebt.toFixed(1)} جنيه</span>
              <p className="text-[11px] text-stone-400 mt-1">واجبة التحصيل</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-xs text-stone-400 block font-semibold">إجمالي عدد الطلبات</span>
              <span className="text-2xl font-black text-stone-900">{orders.length} طلب</span>
              <p className="text-[11px] text-stone-400 mt-1">عبر كافة المتاجر</p>
            </div>
          </div>

          {/* Recent Orders table */}
          <div className="bg-white rounded-3xl border border-stone-200 p-5 shadow-xs space-y-3">
            <h3 className="font-black text-stone-900 text-base">أحدث الطلبات الواردة للمنصة</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-stone-50 text-stone-600 font-bold border-b border-stone-200">
                  <tr>
                    <th className="p-3">رقم الطلب</th>
                    <th className="p-3">العميل</th>
                    <th className="p-3">الهاتف</th>
                    <th className="p-3">المجموع</th>
                    <th className="p-3">طريقة الدفع</th>
                    <th className="p-3">الحالة</th>
                    <th className="p-3">المندوب</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {orders.slice(0, 5).map(o => (
                    <tr key={o.id} className="hover:bg-stone-50">
                      <td className="p-3 font-mono font-bold text-emerald-800">#{o.orderNumber}</td>
                      <td className="p-3 font-semibold text-stone-800">{o.customerName}</td>
                      <td className="p-3 text-stone-500">{o.customerPhone}</td>
                      <td className="p-3 font-black text-stone-900">{o.total} ج</td>
                      <td className="p-3 text-stone-600">{o.paymentMethod}</td>
                      <td className="p-3">
                        <span className="bg-stone-100 text-stone-800 px-2 py-0.5 rounded-full font-bold">
                          {o.status}
                        </span>
                      </td>
                      <td className="p-3 text-stone-600">{o.driverName || 'لم يعين بعد'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: ORDERS ================= */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-black text-lg text-stone-900">سجل الطلبات المركزي للرقابة</h2>
            <span className="text-xs text-stone-500 font-semibold">{orders.length} طلب مسجل</span>
          </div>

          <div className="space-y-3">
            {orders.map(order => (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-stone-200 p-4 space-y-3 shadow-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-stone-100">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-emerald-800 text-sm">
                      #{order.orderNumber}
                    </span>
                    <span className="text-xs text-stone-500 font-semibold">
                      العميل: {order.customerName} ({order.customerPhone})
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-400">تغيير الحالة:</span>
                    <select
                      value={order.status}
                      disabled={!canEditOrders}
                      onChange={e => updateOrderStatus(order.id, e.target.value as OrderStatus)}
                      className="bg-stone-50 border border-stone-200 rounded-lg text-xs font-bold px-2.5 py-1 text-stone-800"
                    >
                      <option value="new">جديد</option>
                      <option value="preparing">جاري التجهيز</option>
                      <option value="out_for_delivery">خرج للتوصيل</option>
                      <option value="delivered">تم التسليم</option>
                      <option value="cancelled">ملغي</option>
                    </select>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-stone-600">
                  <span>
                    العنوان: {order.customerAddress.governorate} - {order.customerAddress.cityOrDistrict} - {order.customerAddress.street}
                  </span>
                  <div className="flex items-center gap-3">
                    <span>
                      وسيلة الدفع: <strong>{order.paymentMethod}</strong>
                    </span>
                    <span className="font-black text-emerald-700 text-sm">
                      الإجمالي: {order.total} جنيه
                    </span>
                  </div>
                </div>

                {order.driverName && (
                  <div className="text-[11px] text-purple-800 bg-purple-50 p-2 rounded-lg flex items-center justify-between">
                    <span>المندوب: {order.driverName} ({order.driverPhone})</span>
                    <span>تم إشعار العميل</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB: PRODUCTS & AGREED OFFERS MANAGEMENT ================= */}
      {activeTab === 'products' && (
        <div className="space-y-5">
          {/* Header */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-black text-lg md:text-xl text-stone-900">
                  إدارة المنتجات وعروض التجار
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-xs px-2.5 py-0.5 rounded-full font-bold">
                  {products.length} صنف مسجل
                </span>
              </div>
              <p className="text-xs text-stone-500 mt-1">
                إضافة وتعديل وحذف المنتجات لأي تاجر، عمل عروض وتخفيضات بالاتفاق المباشر، والتحكم الفوري في ظهور المنتجات للعملاء.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                disabled={!canEditProducts}
                onClick={() => handleOpenAddProduct()}
                className={`px-4 py-2.5 rounded-xl text-xs md:text-sm font-extrabold shadow-md flex items-center gap-2 transition cursor-pointer ${
                  canEditProducts
                    ? 'bg-emerald-700 hover:bg-emerald-800 text-white'
                    : 'bg-stone-300 text-stone-500 cursor-not-allowed'
                }`}
              >
                <Plus className="w-4 h-4" />
                <span>إضافة منتج جديد للمتجر</span>
              </button>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-3.5 rounded-2xl border border-stone-200">
              <span className="text-[11px] text-stone-400 block font-semibold">إجمالي المنتجات</span>
              <span className="text-xl font-black text-stone-800">{products.length}</span>
            </div>
            <div className="bg-white p-3.5 rounded-2xl border border-stone-200">
              <span className="text-[11px] text-stone-400 block font-semibold">ظاهرة بالمتجر</span>
              <span className="text-xl font-black text-emerald-700">
                {products.filter(p => !p.isHidden).length}
              </span>
            </div>
            <div className="bg-white p-3.5 rounded-2xl border border-stone-200">
              <span className="text-[11px] text-stone-400 block font-semibold">عروض بالاتفاق مع التاجر</span>
              <span className="text-xl font-black text-amber-600">
                {products.filter(p => p.discountPrice && p.discountPrice < p.price).length}
              </span>
            </div>
            <div className="bg-white p-3.5 rounded-2xl border border-stone-200">
              <span className="text-[11px] text-stone-400 block font-semibold">أصناف مخفية</span>
              <span className="text-xl font-black text-stone-500">
                {products.filter(p => p.isHidden).length}
              </span>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="bg-white p-3.5 rounded-2xl border border-stone-200 flex flex-wrap items-center justify-between gap-3 shadow-xs">
            <div className="flex flex-wrap items-center gap-2.5 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[180px]">
                <Search className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  value={prodFilterSearch}
                  onChange={e => setProdFilterSearch(e.target.value)}
                  placeholder="بحث باسم الصنف أو التاجر..."
                  className="w-full pr-9 pl-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              {/* Trader Filter */}
              <select
                value={prodFilterTrader}
                onChange={e => setProdFilterTrader(e.target.value)}
                className="bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded-xl px-3 py-2 focus:outline-none"
              >
                <option value="all">كل المتاجر والتجار</option>
                {allTraders.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.storeName || t.name}
                  </option>
                ))}
              </select>

              {/* Category Filter */}
              <select
                value={prodFilterCategory}
                onChange={e => setProdFilterCategory(e.target.value)}
                className="bg-stone-50 border border-stone-200 text-stone-800 text-xs rounded-xl px-3 py-2 focus:outline-none"
              >
                <option value="all">كل الأقسام</option>
                <option value="vegetables">خضروات</option>
                <option value="fruits">فواكه</option>
                <option value="legumes_cheese">بقوليات وجبن</option>
                <option value="dried_goods">مجففات وعطارة</option>
              </select>

              {/* Only Offers Checkbox */}
              <label className="flex items-center gap-1.5 text-xs font-bold text-amber-800 cursor-pointer bg-amber-50 px-2.5 py-2 rounded-xl border border-amber-200">
                <input
                  type="checkbox"
                  checked={prodFilterOffersOnly}
                  onChange={e => setProdFilterOffersOnly(e.target.checked)}
                  className="rounded text-amber-600 focus:ring-amber-500 w-3.5 h-3.5"
                />
                <span>عروض وتخفيضات بالاتفاق فقط 🏷️</span>
              </label>
            </div>
          </div>

          {/* Products List / Grid */}
          {products.filter(p => {
            if (prodFilterTrader !== 'all' && p.traderId !== prodFilterTrader) return false;
            if (prodFilterCategory !== 'all' && p.category !== prodFilterCategory) return false;
            if (prodFilterOffersOnly && (!p.discountPrice || p.discountPrice >= p.price)) return false;
            if (prodFilterSearch.trim()) {
              const q = prodFilterSearch.trim().toLowerCase();
              const matchName = p.name.toLowerCase().includes(q);
              const matchTrader = p.traderName.toLowerCase().includes(q);
              if (!matchName && !matchTrader) return false;
            }
            return true;
          }).length === 0 ? (
            <div className="bg-white rounded-3xl p-10 text-center border border-stone-200">
              <Store className="w-12 h-12 text-stone-300 mx-auto mb-2" />
              <h3 className="font-bold text-stone-700">لا توجد منتجات مطابقة لخيارات البحث</h3>
              <p className="text-xs text-stone-400 mt-1">
                يمكنك إضافة منتج جديد لأي تاجر بسهولة من زر "+ إضافة منتج جديد للمتجر" أعلاه.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products
                .filter(p => {
                  if (prodFilterTrader !== 'all' && p.traderId !== prodFilterTrader) return false;
                  if (prodFilterCategory !== 'all' && p.category !== prodFilterCategory) return false;
                  if (prodFilterOffersOnly && (!p.discountPrice || p.discountPrice >= p.price)) return false;
                  if (prodFilterSearch.trim()) {
                    const q = prodFilterSearch.trim().toLowerCase();
                    const matchName = p.name.toLowerCase().includes(q);
                    const matchTrader = p.traderName.toLowerCase().includes(q);
                    if (!matchName && !matchTrader) return false;
                  }
                  return true;
                })
                .map(prod => {
                  const hasActiveOffer = Boolean(prod.discountPrice && prod.discountPrice < prod.price);
                  const savings = hasActiveOffer ? prod.price - (prod.discountPrice || 0) : 0;

                  return (
                    <div
                      key={prod.id}
                      className={`bg-white rounded-2xl border p-4 shadow-xs space-y-3 transition flex flex-col justify-between ${
                        prod.isHidden ? 'opacity-60 bg-stone-50 border-stone-200' : 'border-stone-200 hover:shadow-md'
                      }`}
                    >
                      <div className="space-y-3">
                        {/* Top: Image + Info */}
                        <div className="flex gap-3">
                          <img
                            src={prod.image}
                            alt={prod.name}
                            className="w-20 h-20 rounded-xl object-cover shrink-0 bg-stone-100 border border-stone-200"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-1">
                              <h3 className="font-black text-sm text-stone-900 leading-snug line-clamp-2">
                                {prod.name}
                              </h3>
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                                  prod.isHidden ? 'bg-stone-200 text-stone-600' : 'bg-emerald-100 text-emerald-800'
                                }`}
                              >
                                {prod.isHidden ? 'مخفي' : 'ظاهر'}
                              </span>
                            </div>

                            <p className="text-[11px] text-stone-500 mt-1 flex items-center gap-1 truncate">
                              <Store className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              <span className="truncate">{prod.traderName}</span>
                            </p>

                            <div className="flex items-center gap-2 mt-1.5">
                              {hasActiveOffer ? (
                                <div className="flex items-baseline gap-1.5">
                                  <span className="text-base font-black text-amber-600">
                                    {prod.discountPrice} ج
                                  </span>
                                  <span className="text-xs text-stone-400 line-through">
                                    {prod.price} ج
                                  </span>
                                  <span className="text-[10px] text-stone-500">/ {prod.unit}</span>
                                </div>
                              ) : (
                                <div className="text-sm font-black text-emerald-700">
                                  {prod.price} جنيه <span className="text-[10px] text-stone-500 font-normal">/ {prod.unit}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Offer Badge & Details */}
                        {hasActiveOffer ? (
                          <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl flex items-center justify-between text-xs">
                            <div className="flex items-center gap-1.5 text-amber-900 font-bold">
                              <span>🏷️ {prod.freshnessBadge || 'عرض خاص بالاتفاق'}</span>
                            </div>
                            <span className="text-[11px] font-black text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                              توفير {savings} جنيه
                            </span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between text-xs text-stone-500">
                            <span>المخزون: <strong>{prod.stock} {prod.unit}</strong></span>
                            <span className="bg-stone-100 text-stone-600 text-[10px] font-bold px-2 py-0.5 rounded-md">
                              {prod.freshnessBadge || 'فرز أول'}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Actions Bar */}
                      <div className="pt-2 border-t border-stone-100 flex flex-wrap items-center justify-between gap-1.5">
                        <div className="flex items-center gap-1.5">
                          {/* Visibility Toggle */}
                          <button
                            disabled={!canEditProducts}
                            onClick={() => toggleHideProduct(prod.id)}
                            className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${
                              prod.isHidden
                                ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                            }`}
                            title={prod.isHidden ? 'إظهار المنتج في المتجر' : 'إخفاء المنتج مؤقتاً'}
                          >
                            {prod.isHidden ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                            <span className="hidden sm:inline">{prod.isHidden ? 'إظهار' : 'إخفاء'}</span>
                          </button>

                          {/* Quick Offer Button */}
                          <button
                            disabled={!canEditProducts}
                            onClick={() => {
                              setDealModalProduct(prod);
                              setQuickDealDiscount(prod.discountPrice || Math.max(1, Math.round(prod.price * 0.85)));
                              setQuickDealBadge(prod.freshnessBadge || 'عرض خاص بالاتفاق مع التاجر');
                            }}
                            className="p-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-800 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                            title="عمل عرض وتخفيض بالاتفاق مع التاجر"
                          >
                            <span>🏷️</span>
                            <span className="hidden sm:inline">عرض بالاتفاق</span>
                          </button>
                        </div>

                        <div className="flex items-center gap-1.5">
                          {/* Edit Button */}
                          <button
                            disabled={!canEditProducts}
                            onClick={() => handleOpenEditProduct(prod)}
                            className="p-1.5 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                            title="تعديل بيانات المنتج"
                          >
                            <Edit className="w-3.5 h-3.5" />
                            <span>تعديل</span>
                          </button>

                          {/* Delete Button */}
                          <button
                            disabled={!canEditProducts}
                            onClick={() => {
                              if (window.confirm(`هل أنت متأكد من حذف المنتج "${prod.name}" نهائياً من المتجر؟`)) {
                                deleteProduct(prod.id);
                              }
                            }}
                            className="p-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                            title="حذف المنتج نهائياً"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* ================= TAB 3: TRADERS & DEBT & BAN ================= */}
      {activeTab === 'traders' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-black text-lg text-stone-900">
                إدارة التجار والمزارع والمديونيات
              </h2>
              <p className="text-xs text-stone-500">
                تصفير المديونية، حظر التاجر المخالف مع رسالة واتساب آلية، وإخفاء منتجاته فوراً
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  value={traderSearch}
                  onChange={e => setTraderSearch(e.target.value)}
                  placeholder="بحث باسم التاجر أو المتجر..."
                  className="w-full pr-8 pl-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800"
                />
              </div>

              <button
                onClick={() => {
                  setUName('');
                  setUPhone('');
                  setUEmail('');
                  setUPassword('123456');
                  setURole('trader');
                  setUStoreName('');
                  setIsUserModalOpen(true);
                }}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة تاجر جديد</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {allTraders
              .filter(
                t =>
                  t.name.toLowerCase().includes(traderSearch.toLowerCase()) ||
                  t.storeName?.toLowerCase().includes(traderSearch.toLowerCase())
              )
              .map(trader => {
                const traderProds = products.filter(p => p.traderId === trader.id);

                return (
                  <div
                    key={trader.id}
                    className={`bg-white rounded-3xl border p-5 space-y-4 shadow-xs transition ${
                      trader.isBanned
                        ? 'border-red-300 bg-red-50/20'
                        : 'border-stone-200'
                    }`}
                  >
                    {/* Trader Title */}
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-black text-stone-900 text-sm md:text-base">
                            {trader.storeName || trader.name}
                          </h3>
                        </div>
                        <p className="text-xs text-stone-500 mt-0.5">
                          الاسم: {trader.name} | الهاتف: {trader.phone}
                        </p>
                        <p className="text-[11px] text-stone-400">
                          {trader.address?.governorate} - {trader.address?.cityOrDistrict}
                        </p>
                      </div>

                      {trader.isBanned ? (
                        <span className="bg-red-600 text-white text-[10px] font-black px-2.5 py-1 rounded-full">
                          محظور 🚫
                        </span>
                      ) : (
                        <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full">
                          نشط ومعتمد ✅
                        </span>
                      )}
                    </div>

                    {/* Financial Metrics */}
                    <div className="grid grid-cols-2 gap-2 bg-stone-50 p-3 rounded-2xl border border-stone-200 text-xs">
                      <div>
                        <span className="text-[10px] text-stone-400 block">إجمالي مبيعاته</span>
                        <span className="font-black text-stone-800">{trader.totalSales || 0} ج</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-stone-400 block">المديونية الحالية</span>
                        <span className="font-black text-red-600">{trader.debt || 0} ج</span>
                      </div>
                    </div>

                    {/* Ban reason if banned */}
                    {trader.isBanned && (
                      <div className="bg-red-50 p-2.5 rounded-xl border border-red-200 text-xs text-red-900">
                        <strong className="block">سبب الحظر:</strong>
                        <p className="text-[11px]">{trader.banReason || 'مخالفة الشروط'}</p>
                      </div>
                    )}

                    {/* Actions */}
                    <div className="pt-2 border-t border-stone-100 flex flex-wrap items-center justify-between gap-2">
                      {/* Zero debt */}
                      {canEditDebts && (
                        <button
                          onClick={() => {
                            if (window.confirm(`هل أنت متأكد من تصفير مديونية التاجر (${trader.debt || 0} ج) بعد التحقق من السداد؟`)) {
                              zeroTraderDebt(trader.id);
                            }
                          }}
                          className="px-2.5 py-1 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-700 rounded-lg text-xs font-semibold transition"
                          title="تصفير المديونية بعد التأكد من الدفع"
                        >
                          تصفير المديونية 0 ج
                        </button>
                      )}

                      {/* Add Product for Trader: "ممكن الأدمن والمشرفين يضيفوا منتجات للتاجر" */}
                      {canEditProducts && (
                        <button
                          onClick={() => {
                            setTraderProdModalTrader(trader);
                            setNewProdName('');
                            setNewProdCategory('vegetables');
                            setNewProdPrice(20);
                            setNewProdUnit('كجم');
                            setNewProdStock(50);
                            setNewProdImage('https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80');
                            setNewProdDesc('');
                          }}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-xs font-semibold transition flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>إضافة منتج للتاجر</span>
                        </button>
                      )}

                      {/* Ban / Unban */}
                      {canEditTraders && (
                        trader.isBanned ? (
                          <button
                            onClick={() => unbanTrader(trader.id)}
                            className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition"
                          >
                            رفع الحظر وإعادة المنتجات
                          </button>
                        ) : (
                          <button
                            onClick={() => {
                              setBanModalTrader(trader);
                              setBanWhatsAppLink('');
                            }}
                            className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1"
                          >
                            <ShieldAlert className="w-3.5 h-3.5" />
                            <span>حظر التاجر</span>
                          </button>
                        )
                      )}

                      <button
                        onClick={() => {
                          if (window.confirm('هل تريد حذف هذا التاجر نهائياً من النظام؟')) {
                            deleteUser(trader.id);
                          }
                        }}
                        className="p-1 text-stone-400 hover:text-red-600 transition"
                        title="حذف التاجر"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* ================= TAB 4: SUPERVISORS MANAGEMENT ================= */}
      {activeTab === 'supervisors' && currentUser?.role === 'admin' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-black text-lg text-stone-900">
                إدارة المشرفين وتخصيص الصلاحيات
              </h2>
              <p className="text-xs text-stone-500">
                إضافة مشرفين، تحديد الصلاحيات لكل قسم بدقة، وتعيين تخصص المشرف
              </p>
            </div>

            <button
              onClick={() => {
                setEditingSupervisor(null);
                setSupName('');
                setSupEmail('');
                setSupPhone('');
                setSupPassword('Password123');
                setSupTitle('مشرف رقابة الجودة');
                setIsSupervisorModalOpen(true);
              }}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة مشرف جديد</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {allSupervisors.map(sup => (
              <div
                key={sup.id}
                className="bg-white rounded-3xl border border-stone-200 p-5 space-y-3 shadow-xs"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-black text-stone-900 text-sm md:text-base">{sup.name}</h3>
                    <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-md mt-1 inline-block">
                      {sup.supervisorTitle || 'مشرف معتمد'}
                    </span>
                    <p className="text-xs text-stone-500 mt-1">
                      البريد: {sup.email} | الهاتف: {sup.phone}
                    </p>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingSupervisor(sup);
                        setSupName(sup.name);
                        setSupEmail(sup.email);
                        setSupPhone(sup.phone);
                        setSupPassword(sup.password || '');
                        setSupTitle(sup.supervisorTitle || '');
                        if (sup.supervisorPermissions) setSupPermissions(sup.supervisorPermissions);
                        setIsSupervisorModalOpen(true);
                      }}
                      className="p-1.5 text-stone-500 hover:text-emerald-700 hover:bg-stone-100 rounded-lg"
                      title="تعديل الصلاحيات"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => deleteUser(sup.id)}
                      className="p-1.5 text-stone-500 hover:text-red-700 hover:bg-stone-100 rounded-lg"
                      title="حذف المشرف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Permissions Badges */}
                <div className="pt-2 border-t border-stone-100 space-y-1">
                  <span className="text-[11px] font-bold text-stone-500 block">الصلاحيات الممنوحة:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {sup.supervisorPermissions?.canManageOrders && (
                      <span className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md font-semibold">
                        إدارة الطلبات
                      </span>
                    )}
                    {sup.supervisorPermissions?.canManageProducts && (
                      <span className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md font-semibold">
                        إدارة المنتجات
                      </span>
                    )}
                    {sup.supervisorPermissions?.canManageTraders && (
                      <span className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md font-semibold">
                        حظر وإدارة التجار
                      </span>
                    )}
                    {sup.supervisorPermissions?.canManageDebts && (
                      <span className="text-[10px] bg-purple-100 text-purple-800 px-2 py-0.5 rounded-md font-semibold">
                        تصفير المديونيات
                      </span>
                    )}
                    {sup.supervisorPermissions?.canManageAds && (
                      <span className="text-[10px] bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md font-semibold">
                        إدارة الإعلانات
                      </span>
                    )}
                    {sup.supervisorPermissions?.canHandleResets && (
                      <span className="text-[10px] bg-blue-100 text-blue-800 px-2 py-0.5 rounded-md font-semibold">
                        استعادة كلمة السر
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 5: CUSTOMERS MANAGEMENT ================= */}
      {activeTab === 'customers' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-black text-lg text-stone-900">إدارة حسابات العملاء</h2>
              <p className="text-xs text-stone-500">
                إضافة عميل يدوياً، حظر أو رفع الحظر، ومراجعة العناوين المفصلة
              </p>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative min-w-[200px]">
                <Search className="w-3.5 h-3.5 text-stone-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  value={customerSearch}
                  onChange={e => setCustomerSearch(e.target.value)}
                  placeholder="بحث باسم العميل أو هاتفه..."
                  className="w-full pr-8 pl-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs text-stone-800"
                />
              </div>

              <button
                onClick={() => {
                  setUName('');
                  setUPhone('');
                  setUEmail('');
                  setUPassword('123456');
                  setURole('customer');
                  setIsUserModalOpen(true);
                }}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>إضافة عميل جديد</span>
              </button>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold">
                  <tr>
                    <th className="p-3.5">الاسم</th>
                    <th className="p-3.5">الهاتف</th>
                    <th className="p-3.5">البريد الإلكتروني</th>
                    <th className="p-3.5">العنوان بالتفصيل</th>
                    <th className="p-3.5">الحالة</th>
                    <th className="p-3.5 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {allCustomers
                    .filter(
                      c =>
                        c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
                        c.phone.includes(customerSearch)
                    )
                    .map(cust => (
                      <tr key={cust.id} className="hover:bg-stone-50 transition">
                        <td className="p-3.5 font-bold text-stone-800">{cust.name}</td>
                        <td className="p-3.5 font-mono text-stone-600">{cust.phone}</td>
                        <td className="p-3.5 text-stone-500">{cust.email}</td>
                        <td className="p-3.5 text-stone-600 max-w-xs">
                          {cust.address
                            ? `${cust.address.governorate} - ${cust.address.cityOrDistrict} - ${cust.address.street}`
                            : 'غير محدد'}
                        </td>
                        <td className="p-3.5">
                          {cust.isBanned ? (
                            <span className="bg-red-100 text-red-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              محظور
                            </span>
                          ) : (
                            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              نشط
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            {cust.isBanned ? (
                              <button
                                onClick={() => unbanCustomer(cust.id)}
                                className="px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg text-[11px] font-bold"
                              >
                                رفع الحظر
                              </button>
                            ) : (
                              <button
                                onClick={() => banCustomer(cust.id, 'مخالفة سياسة الطلبات')}
                                className="px-2.5 py-1 bg-red-50 text-red-700 hover:bg-red-100 rounded-lg text-[11px] font-bold"
                              >
                                حظر العميل
                              </button>
                            )}
                            <button
                              onClick={() => {
                                if (window.confirm('هل تريد حذف هذا العميل؟')) {
                                  deleteUser(cust.id);
                                }
                              }}
                              className="p-1 text-stone-400 hover:text-red-600"
                              title="حذف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 6: ADS MANAGEMENT ================= */}
      {activeTab === 'ads' && canEditAds && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-black text-lg text-stone-900">
                إدارة الإعلانات والحملات الترويجية بالمتجر
              </h2>
              <p className="text-xs text-stone-500">
                رفع الإعلانات مباشرة من الهاتف أو الكمبيوتر وتحديد التواريخ والأقسام
              </p>
            </div>

            <button
              onClick={() => {
                setAdTitle('');
                setAdDescription('');
                setAdBadge('عرض مميز');
                setAdImage('');
                setIsAdModalOpen(true);
              }}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة إعلان جديد بالصورة</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ads.map(ad => (
              <div
                key={ad.id}
                className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs flex flex-col justify-between"
              >
                <div className="relative aspect-video bg-stone-100">
                  <img src={ad.image} alt={ad.title} className="w-full h-full object-cover" />
                  {ad.badgeText && (
                    <span className="absolute top-3 right-3 bg-amber-400 text-stone-900 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow">
                      {ad.badgeText}
                    </span>
                  )}
                  <span
                    className={`absolute bottom-3 left-3 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      ad.isActive ? 'bg-green-600 text-white' : 'bg-stone-800 text-white'
                    }`}
                  >
                    {ad.isActive ? 'نشط في المتجر' : 'متوقف مؤقتاً'}
                  </span>
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="font-bold text-stone-900 text-sm md:text-base">{ad.title}</h3>
                  <p className="text-xs text-stone-500 line-clamp-2">{ad.description}</p>
                  <div className="text-[11px] text-stone-400">
                    الصلاحية: من {ad.startDate} إلى {ad.endDate}
                  </div>

                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                    <button
                      onClick={() => updateAd(ad.id, { isActive: !ad.isActive })}
                      className="text-xs font-bold text-stone-600 hover:text-emerald-700"
                    >
                      {ad.isActive ? 'إيقاف مؤقت' : 'تفعيل الإعلان'}
                    </button>

                    <button
                      onClick={() => deleteAd(ad.id)}
                      className="p-1 text-stone-400 hover:text-red-600 transition"
                      title="حذف الإعلان"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ================= TAB 7: PASSWORD RESETS ================= */}
      {activeTab === 'resets' && canHandleResets && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-black text-lg text-stone-900">
                طلبات استعادة كلمة السر الواردة
              </h2>
              <p className="text-xs text-stone-500">
                عند النقر على إرسال عبر الواتساب، يتم توليد كلمة مرور مؤقتة وتوجيه الرسالة مباشرة لرقم العضو
              </p>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold">
                  <tr>
                    <th className="p-3.5">الاسم / الحساب</th>
                    <th className="p-3.5">رقم الهاتف</th>
                    <th className="p-3.5">تاريخ الطلب</th>
                    <th className="p-3.5">الحالة</th>
                    <th className="p-3.5 text-center">الإجراء المباشر</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {resetRequests.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-stone-400">
                        لا توجد طلبات معلقة حالياً
                      </td>
                    </tr>
                  ) : (
                    resetRequests.map(req => (
                      <tr key={req.id} className="hover:bg-stone-50">
                        <td className="p-3.5 font-bold text-stone-800">
                          {req.userName || 'مستخدم مسجل'} ({req.userRole})
                        </td>
                        <td className="p-3.5 font-mono text-stone-700">{req.phone}</td>
                        <td className="p-3.5 text-stone-500">
                          {new Date(req.requestedAt).toLocaleString('ar-EG')}
                        </td>
                        <td className="p-3.5">
                          {req.status === 'resolved' ? (
                            <span className="bg-green-100 text-green-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                              تم الإرسال
                            </span>
                          ) : (
                            <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse">
                              بانتظار الرد 📲
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 text-center">
                          <button
                            onClick={() => {
                              const waUrl = resolvePasswordReset(req.id);
                              if (waUrl) {
                                window.open(waUrl, '_blank');
                              }
                            }}
                            className="px-3.5 py-1.5 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 mx-auto shadow-xs"
                          >
                            <MessageCircle className="w-3.5 h-3.5" />
                            <span>إرسال بيانات الدخول واتساب</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 8: SETTINGS & TEMPLATES ================= */}
      {activeTab === 'settings' && currentUser?.role === 'admin' && (
        <form onSubmit={handleSaveSettings} className="bg-white rounded-3xl border border-stone-200 p-6 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-stone-100">
            <div>
              <h2 className="font-black text-lg text-stone-900">
                إعدادات هوية المتجر وحسابات الدفع
              </h2>
              <p className="text-xs text-stone-500">
                تغيير اسم المتجر، شعاره، أرقام إنستاباي وفودافون كاش، ونسبة العمولة
              </p>
            </div>
            {settingsSaveMsg && (
              <span className="text-xs text-emerald-800 bg-emerald-50 px-3 py-1 rounded-xl font-bold border border-emerald-200">
                {settingsSaveMsg}
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">اسم المتجر / التطبيق</label>
              <input
                type="text"
                value={setStoreName}
                onChange={e => setSetStoreName(e.target.value)}
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">الوصف الفرعي</label>
              <input
                type="text"
                value={setStoreSubtitle}
                onChange={e => setSetStoreSubtitle(e.target.value)}
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
              />
            </div>
          </div>

          {/* Payment Settings */}
          <div className="pt-2 border-t border-stone-100 space-y-3">
            <h3 className="text-sm font-extrabold text-stone-800 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-emerald-700" />
              <span>أرقام وحسابات الدفع الإلكتروني المعتمدة</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  عنوان / حساب إنستاباي (InstaPay)
                </label>
                <input
                  type="text"
                  value={setInstapay}
                  onChange={e => setSetInstapay(e.target.value)}
                  placeholder="name@instapay"
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  رقم محفظة فودافون كاش
                </label>
                <input
                  type="text"
                  value={setVodafone}
                  onChange={e => setSetVodafone(e.target.value)}
                  placeholder="010xxxxxxxx"
                  className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 font-mono"
                  required
                />
              </div>
            </div>
          </div>

          {/* Financial Rates */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-stone-100">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">رسوم التوصيل (جنيه)</label>
              <input
                type="number"
                value={setDeliveryFee}
                onChange={e => setSetDeliveryFee(Number(e.target.value))}
                min="0"
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">نسبة عمولة المنصة (%)</label>
              <input
                type="number"
                value={setCommissionRate}
                onChange={e => setSetCommissionRate(Number(e.target.value))}
                min="0"
                max="50"
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">رقم خدمة العملاء (واتساب)</label>
              <input
                type="text"
                value={setWhatsApp}
                onChange={e => setSetWhatsApp(e.target.value)}
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800"
                required
              />
            </div>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition cursor-pointer text-xs md:text-sm"
            >
              حفظ التعديلات
            </button>
          </div>
        </form>
      )}

      {/* BAN TRADER MODAL WITH AUTOMATED WHATSAPP MESSAGE GENERATOR */}
      {banModalTrader && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-red-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2 text-red-600">
                <ShieldAlert className="w-6 h-6" />
                <h3 className="font-black text-lg text-stone-900">
                  حظر التاجر: {banModalTrader.storeName || banModalTrader.name}
                </h3>
              </div>
              <button onClick={() => setBanModalTrader(null)} className="p-1 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            {banWhatsAppLink ? (
              <div className="p-4 bg-green-50 border border-green-200 rounded-2xl text-center space-y-3">
                <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto" />
                <h4 className="font-bold text-green-900 text-sm">تم تفعيل الحظر وإخفاء المنتجات!</h4>
                <p className="text-xs text-green-800">
                  تم إخفاء جميع منتجات التاجر من المتجر تلقائياً. اضغط بالأسفل لإرسال رسالة الواتساب للتاجر بالسبب والخطوات:
                </p>
                <a
                  href={banWhatsAppLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block py-2 px-5 bg-green-600 hover:bg-green-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
                >
                  فتح محادثة الواتساب التلقائية مع التاجر 📲
                </a>
                <button
                  type="button"
                  onClick={() => setBanModalTrader(null)}
                  className="block w-full py-1 text-stone-500 text-xs hover:underline mt-2"
                >
                  إغلاق
                </button>
              </div>
            ) : (
              <form onSubmit={handleConfirmBanTrader} className="space-y-3">
                <p className="text-xs text-stone-500 leading-relaxed">
                  عند تفعيل الحظر، ستختفي كافة منتجات هذا التاجر من المتجر فوراً، ولن يستطيع استقبال أي طلبات حتى حل المشكلة.
                </p>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">سبب الحظر</label>
                  <input
                    type="text"
                    value={banReason}
                    onChange={e => setBanReason(e.target.value)}
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الخطوات المطلوبة لحل المشكلة ورفع الحظر
                  </label>
                  <textarea
                    value={banResolutionSteps}
                    onChange={e => setBanResolutionSteps(e.target.value)}
                    rows={3}
                    className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-md transition text-xs md:text-sm cursor-pointer"
                  >
                    تأكيد الحظر وإخفاء المنتجات وتوليد الرسالة
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* SUPERVISOR MODAL */}
      {isSupervisorModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-black text-lg text-stone-900">
                {editingSupervisor ? 'تعديل بيانات المشرف' : 'إضافة مشرف جديد'}
              </h3>
              <button onClick={() => setIsSupervisorModalOpen(false)} className="p-1 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSupervisor} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">اسم المشرف</label>
                  <input
                    type="text"
                    value={supName}
                    onChange={e => setSupName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الهاتف</label>
                  <input
                    type="tel"
                    value={supPhone}
                    onChange={e => setSupPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={supEmail}
                    onChange={e => setSupEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">كلمة المرور</label>
                  <input
                    type="text"
                    value={supPassword}
                    onChange={e => setSupPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  تخصص المشرف (المسمى الوظيفي)
                </label>
                <input
                  type="text"
                  value={supTitle}
                  onChange={e => setSupTitle(e.target.value)}
                  placeholder="مشرف جودة / مشرف مبيعات..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  required
                />
              </div>

              {/* Permissions Checkboxes */}
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                <span className="text-xs font-extrabold text-stone-700 block">
                  تحديد الصلاحيات المتاحة في لوحة التحكم:
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canManageOrders}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canManageOrders: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>إدارة ومتابعة الطلبات</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canManageProducts}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canManageProducts: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>إضافة وتعديل المنتجات</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canManageTraders}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canManageTraders: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>إدارة وحظر التجار</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canManageCustomers}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canManageCustomers: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>إدارة وحظر العملاء</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canManageDebts}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canManageDebts: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>تصفير المديونيات</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canManageAds}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canManageAds: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>إدارة إعلانات المتجر</span>
                  </label>

                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={supPermissions.canHandleResets}
                      onChange={e =>
                        setSupPermissions(p => ({ ...p, canHandleResets: e.target.checked }))
                      }
                      className="rounded text-emerald-600"
                    />
                    <span>طلبات كلمة السر</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition text-xs cursor-pointer mt-2"
              >
                حفظ بيانات المشرف
              </button>
            </form>
          </div>
        </div>
      )}

      {/* AD FORM MODAL: WITH DIRECT COMPUTER & PHONE UPLOAD */}
      {isAdModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-black text-lg text-stone-900">إضافة إعلان جديد</h3>
              <button onClick={() => setIsAdModalOpen(false)} className="p-1 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAd} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">عنوان الإعلان</label>
                <input
                  type="text"
                  value={adTitle}
                  onChange={e => setAdTitle(e.target.value)}
                  placeholder="مثال: خصم 20% على الخضار البلدي..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">الوصف التفصيلي</label>
                <textarea
                  value={adDescription}
                  onChange={e => setAdDescription(e.target.value)}
                  rows={2}
                  placeholder="تفاصيل العرض والمميزات..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">بادج التميز</label>
                  <input
                    type="text"
                    value={adBadge}
                    onChange={e => setAdBadge(e.target.value)}
                    placeholder="خصم 20% / طازج..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">القسم المستهدف</label>
                  <select
                    value={adTargetCategory}
                    onChange={e => setAdTargetCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  >
                    <option value="all">كل الأقسام</option>
                    <option value="vegetables">خضروات</option>
                    <option value="fruits">فواكه</option>
                    <option value="legumes_cheese">بقوليات وجبن</option>
                    <option value="dried_goods">مجففات وعطارة</option>
                  </select>
                </div>
              </div>

              {/* IMAGE UPLOAD DIRECTLY FROM PHONE OR PC */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                  <span>صورة الإعلان (رفع من جهازك مباشرة)</span>
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                </label>
                <div className="flex items-center gap-3">
                  {adImage && (
                    <img src={adImage} alt="معاينة" className="w-16 h-12 rounded-lg object-cover border" />
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={e => handleUploadImageFile(e, setAdImage)}
                    className="w-full text-xs text-stone-600 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-800 cursor-pointer"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ البداية</label>
                  <input
                    type="date"
                    value={adStartDate}
                    onChange={e => setAdStartDate(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ النهاية</label>
                  <input
                    type="date"
                    value={adEndDate}
                    onChange={e => setAdEndDate(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition text-xs cursor-pointer mt-2"
              >
                نشر الإعلان في المتجر
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ADMIN ADD PRODUCT FOR A TRADER MODAL */}
      {traderProdModalTrader && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-black text-lg text-stone-900">
                إضافة صنف للتاجر: {traderProdModalTrader.storeName || traderProdModalTrader.name}
              </h3>
              <button onClick={() => setTraderProdModalTrader(null)} className="p-1 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAdminProduct} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">اسم المنتج</label>
                <input
                  type="text"
                  value={newProdName}
                  onChange={e => setNewProdName(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  required
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">القسم</label>
                  <select
                    value={newProdCategory}
                    onChange={e => setNewProdCategory(e.target.value as any)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  >
                    <option value="vegetables">خضروات</option>
                    <option value="fruits">فواكه</option>
                    <option value="legumes_cheese">بقوليات وجبن</option>
                    <option value="dried_goods">مجففات</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">السعر (ج)</label>
                  <input
                    type="number"
                    value={newProdPrice}
                    onChange={e => setNewProdPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الوحدة</label>
                  <input
                    type="text"
                    value={newProdUnit}
                    onChange={e => setNewProdUnit(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                  <span>صورة المنتج (رفع من جهازك)</span>
                  <Upload className="w-3.5 h-3.5 text-emerald-600" />
                </label>
                <div className="flex items-center gap-3">
                  {newProdImage && (
                    <img src={newProdImage} alt="معاينة" className="w-14 h-14 rounded-lg object-cover border" />
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={e => handleUploadImageFile(e, setNewProdImage)}
                    className="w-full text-xs text-stone-600 file:py-1.5 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-50 file:text-emerald-800 cursor-pointer"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition text-xs cursor-pointer mt-2"
              >
                تأكيد وإضافة للمتجر
              </button>
            </form>
          </div>
        </div>
      )}

      {/* USER MODAL (DIRECT ADMIN CREATION OF CUSTOMER OR TRADER) */}
      {isUserModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-black text-lg text-stone-900">
                {uRole === 'trader' ? 'إضافة تاجر من الإدارة' : 'إضافة عميل من الإدارة'}
              </h3>
              <button onClick={() => setIsUserModalOpen(false)} className="p-1 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                addOrUpdateUser({
                  name: uName.trim(),
                  phone: uPhone.trim(),
                  email: uEmail.trim().toLowerCase(),
                  password: uPassword.trim(),
                  role: uRole,
                  storeName: uRole === 'trader' ? uStoreName.trim() : undefined,
                  address: {
                    governorate: 'القاهرة',
                    cityOrDistrict: 'المعادي',
                    street: 'شارع رئيسي',
                    building: '1'
                  }
                });
                setIsUserModalOpen(false);
              }}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">الاسم الكامل</label>
                <input
                  type="text"
                  value={uName}
                  onChange={e => setUName(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  required
                />
              </div>

              {uRole === 'trader' && (
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">اسم المتجر / المزرعة</label>
                  <input
                    type="text"
                    value={uStoreName}
                    onChange={e => setUStoreName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الهاتف</label>
                  <input
                    type="tel"
                    value={uPhone}
                    onChange={e => setUPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={uEmail}
                    onChange={e => setUEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">كلمة المرور</label>
                <input
                  type="text"
                  value={uPassword}
                  onChange={e => setUPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition text-xs cursor-pointer mt-2"
              >
                تأكيد وحفظ الحساب
              </button>
            </form>
          </div>
        </div>
      )}
      {/* MODAL: ADD / EDIT PRODUCT & AGREED DEALS FOR ADMIN & SUPERVISOR */}
      {isProdModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden border border-emerald-100 flex flex-col max-h-[90vh]">
            <div className="bg-gradient-to-r from-emerald-800 to-green-800 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Store className="w-5 h-5 text-amber-300" />
                <h3 className="font-black text-base">
                  {editingProd ? 'تعديل بيانات المنتج والعرض' : 'إضافة صنف جديد لمتجر'}
                </h3>
              </div>
              <button
                onClick={() => setIsProdModalOpen(false)}
                className="p-1 rounded-full bg-white/10 hover:bg-white/20 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-5 overflow-y-auto space-y-4">
              {/* Select Trader */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  المتجر / التاجر صاحب الصنف *
                </label>
                <select
                  value={prodTraderId}
                  onChange={e => setProdTraderId(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 font-bold focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                  required
                >
                  {allTraders.map(t => (
                    <option key={t.id} value={t.id}>
                      {t.storeName || t.name} ({t.phone})
                    </option>
                  ))}
                </select>
              </div>

              {/* Product Name */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  اسم الصنف بالكامل *
                </label>
                <input
                  type="text"
                  value={prodName}
                  onChange={e => setProdName(e.target.value)}
                  placeholder="مثال: طماطم بلدي سلك فرز أول..."
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs md:text-sm text-stone-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  required
                />
              </div>

              {/* Category & Badge */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">القسم *</label>
                  <select
                    value={prodCategory}
                    onChange={e => setProdCategory(e.target.value as ProductCategory)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 font-semibold"
                  >
                    <option value="vegetables">خضروات طازجة</option>
                    <option value="fruits">فواكه الموسم</option>
                    <option value="legumes_cheese">بقوليات وجبن بلدي</option>
                    <option value="dried_goods">مجففات وعطارة</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">شارة الجودة</label>
                  <input
                    type="text"
                    value={prodBadge}
                    onChange={e => setProdBadge(e.target.value)}
                    placeholder="فرز أول / قطفة الصباح"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                  />
                </div>
              </div>

              {/* Price, Unit & Stock */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    السعر الأصلي (جنيه) *
                  </label>
                  <input
                    type="number"
                    value={prodPrice}
                    onChange={e => setProdPrice(Number(e.target.value))}
                    min="1"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 font-bold"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الوحدة *</label>
                  <input
                    type="text"
                    value={prodUnit}
                    onChange={e => setProdUnit(e.target.value)}
                    placeholder="كجم / طبق / عبوة"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">المخزون *</label>
                  <input
                    type="number"
                    value={prodStock}
                    onChange={e => setProdStock(Number(e.target.value))}
                    min="0"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />
                </div>
              </div>

              {/* Special Offer Agreement Section */}
              <div className="p-3.5 bg-amber-50 rounded-2xl border border-amber-200 space-y-2.5">
                <label className="flex items-center gap-2 cursor-pointer text-xs font-extrabold text-amber-900">
                  <input
                    type="checkbox"
                    checked={prodHasOffer}
                    onChange={e => setProdHasOffer(e.target.checked)}
                    className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4"
                  />
                  <span>عمل عرض وتخفيض خاص بالاتفاق مع التاجر 🏷️</span>
                </label>

                {prodHasOffer && (
                  <div className="space-y-2 pt-1 animate-fadeIn">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-amber-900 mb-1">
                          سعر البيع بعد الخصم (جنيه) *
                        </label>
                        <input
                          type="number"
                          value={prodDiscountPrice || ''}
                          onChange={e => setProdDiscountPrice(Number(e.target.value))}
                          placeholder="مثال: 15"
                          min="1"
                          max={prodPrice - 1}
                          className="w-full px-3 py-1.5 bg-white border border-amber-300 rounded-xl text-xs text-stone-800 font-bold"
                          required={prodHasOffer}
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-amber-900 mb-1">
                          شارة العرض الترويجية
                        </label>
                        <input
                          type="text"
                          value={prodOfferBadge}
                          onChange={e => setProdOfferBadge(e.target.value)}
                          placeholder="عرض خاص بالاتفاق مع التاجر"
                          className="w-full px-3 py-1.5 bg-white border border-amber-300 rounded-xl text-xs text-stone-800"
                        />
                      </div>
                    </div>
                    <p className="text-[11px] text-amber-700 leading-relaxed">
                      عند التفعيل، سيظهر الصنف في قسم العروض بالصفحة الرئيسية مع شطب السعر الأصلي ({prodPrice} ج) وإبراز التوفير للعملاء فوراً.
                    </p>
                  </div>
                )}
              </div>

              {/* Image Upload */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1 flex items-center justify-between">
                  <span>صورة الصنف *</span>
                  <span className="text-[10px] text-stone-400">ملف من جهازك أو رابط مباشر</span>
                </label>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <label className="flex-1 flex items-center justify-center gap-2 px-3 py-2 border-2 border-dashed border-stone-300 hover:border-emerald-600 rounded-xl text-xs font-bold text-stone-600 hover:text-emerald-700 cursor-pointer transition bg-stone-50">
                      <Upload className="w-4 h-4" />
                      <span>اختيار صورة من الموبايل أو الكمبيوتر</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={e => handleUploadImageFile(e, setProdImage)}
                      />
                    </label>
                  </div>

                  <input
                    type="url"
                    value={prodImage}
                    onChange={e => setProdImage(e.target.value)}
                    placeholder="أو الصق رابط صورة مباشر هنا..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                    required
                  />

                  {prodImage && (
                    <div className="w-20 h-20 rounded-xl overflow-hidden border border-stone-200 bg-stone-100">
                      <img src={prodImage} alt="معاينة" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  الوصف والمواصفات
                </label>
                <textarea
                  value={prodDesc}
                  onChange={e => setProdDesc(e.target.value)}
                  placeholder="صنف بلدي فرز أول طازج ونظيف..."
                  rows={2}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold rounded-xl shadow-md transition text-xs md:text-sm cursor-pointer"
                >
                  {editingProd ? 'حفظ وتحديث الصنف والعرض' : 'إضافة الصنف للمتجر فوراً'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsProdModalOpen(false)}
                  className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: QUICK AGREED DEAL / OFFER */}
      {dealModalProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full shadow-2xl overflow-hidden border border-amber-200">
            <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-stone-900 p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">🏷️</span>
                <div>
                  <h3 className="font-black text-sm md:text-base">عمل عرض خاص بالاتفاق مع التاجر</h3>
                  <p className="text-[11px] text-amber-950 font-semibold">{dealModalProduct.name}</p>
                </div>
              </div>
              <button
                onClick={() => setDealModalProduct(null)}
                className="p-1 rounded-full bg-stone-900/10 hover:bg-stone-900/20 transition"
              >
                <X className="w-5 h-5 text-stone-900" />
              </button>
            </div>

            <form onSubmit={handleSaveQuickDeal} className="p-5 space-y-4">
              <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 text-xs text-stone-600 flex items-center justify-between">
                <span>السعر الأصلي الحالي:</span>
                <span className="font-black text-stone-900 text-sm">{dealModalProduct.price} جنيه / {dealModalProduct.unit}</span>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  سعر البيع بعد الخصم المتفق عليه (جنيه) *
                </label>
                <input
                  type="number"
                  value={quickDealDiscount}
                  onChange={e => setQuickDealDiscount(Number(e.target.value))}
                  min="1"
                  max={dealModalProduct.price - 1}
                  className="w-full px-3 py-2 bg-stone-50 border border-amber-300 rounded-xl text-sm font-black text-amber-700 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  required
                />
                <span className="text-[11px] text-emerald-700 font-bold block mt-1">
                  مقدار التوفير للعميل: {dealModalProduct.price - quickDealDiscount} جنيه
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  شارة العرض الترويجية
                </label>
                <input
                  type="text"
                  value={quickDealBadge}
                  onChange={e => setQuickDealBadge(e.target.value)}
                  placeholder="عرض خاص بالاتفاق مع التاجر"
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs text-stone-800"
                  required
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-900 font-black rounded-xl shadow-md transition text-xs md:text-sm cursor-pointer"
                >
                  تفعيل العرض فوراً في المتجر 🏷️
                </button>
                <button
                  type="button"
                  onClick={() => setDealModalProduct(null)}
                  className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
