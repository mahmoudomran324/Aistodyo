import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import {
  Wallet,
  Receipt,
  CreditCard,
  Smartphone,
  Banknote,
  ArrowUpRight,
  Filter,
  CheckCircle2,
  Clock,
  Printer,
  Calendar,
  DollarSign
} from 'lucide-react';

export const CustomerFinancials: React.FC = () => {
  const { transactions, currentUser, orders } = useStore();
  const [filterMethod, setFilterMethod] = useState<string>('all');
  const [selectedTx, setSelectedTx] = useState<any | null>(null);

  // Filter transactions for current user (or guest sessions)
  const userTransactions = transactions.filter(t => {
    if (currentUser) {
      return t.userId === currentUser.id || t.userRole === 'customer';
    }
    return t.userRole === 'customer';
  });

  const filteredTransactions = userTransactions.filter(t => {
    if (filterMethod === 'all') return true;
    return t.paymentMethod === filterMethod;
  });

  const totalSpent = userTransactions
    .filter(t => t.status === 'completed' || t.status === 'pending')
    .reduce((sum, t) => sum + t.amount, 0);

  const completedCount = userTransactions.filter(t => t.status === 'completed').length;
  const pendingCount = userTransactions.filter(t => t.status === 'pending').length;

  const getMethodBadge = (method: string) => {
    switch (method) {
      case 'instapay':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-full border border-purple-200">
            <Smartphone className="w-3 h-3" />
            <span>إنستاباي InstaPay</span>
          </span>
        );
      case 'vodafone_cash':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-red-700 bg-red-50 px-2.5 py-0.5 rounded-full border border-red-200">
            <Smartphone className="w-3 h-3" />
            <span>فودافون كاش</span>
          </span>
        );
      case 'card':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200">
            <CreditCard className="w-3 h-3" />
            <span>فيزا / بطاقة بنكية</span>
          </span>
        );
      case 'cash':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
            <Banknote className="w-3 h-3" />
            <span>كاش عند الاستلام</span>
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="p-2.5 bg-emerald-700 text-white rounded-2xl shadow-sm">
              <Wallet className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black text-stone-900">
                السجل المالي للمدفوعات والمعاملات
              </h1>
              <p className="text-stone-500 text-xs md:text-sm">
                توثيق كامل لكل قيد مالي ورقم معاملة مسجل بقاعدة بيانات المتجر
              </p>
            </div>
          </div>
        </div>

        {/* Stats Summary Cards */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
            <span className="text-[11px] text-stone-400 block font-semibold">إجمالي المشتريات</span>
            <span className="text-lg md:text-xl font-black text-emerald-700">{totalSpent} ج</span>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
            <span className="text-[11px] text-stone-400 block font-semibold">معاملات مسددة</span>
            <span className="text-lg md:text-xl font-black text-stone-900">{completedCount}</span>
          </div>

          <div className="bg-white p-3.5 rounded-2xl border border-stone-200 shadow-xs">
            <span className="text-[11px] text-stone-400 block font-semibold">معاملات معلقة (كاش)</span>
            <span className="text-lg md:text-xl font-black text-amber-600">{pendingCount}</span>
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-3 rounded-2xl border border-stone-200 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 text-xs font-bold text-stone-600">
          <Filter className="w-4 h-4 text-emerald-700" />
          <span>تصفية وسيلة الدفع:</span>
        </div>

        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setFilterMethod('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterMethod === 'all'
                ? 'bg-emerald-700 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            الكل ({userTransactions.length})
          </button>
          <button
            onClick={() => setFilterMethod('cash')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterMethod === 'cash'
                ? 'bg-emerald-700 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            كاش
          </button>
          <button
            onClick={() => setFilterMethod('instapay')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterMethod === 'instapay'
                ? 'bg-purple-700 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            إنستاباي
          </button>
          <button
            onClick={() => setFilterMethod('vodafone_cash')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
              filterMethod === 'vodafone_cash'
                ? 'bg-red-700 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            فودافون كاش
          </button>
        </div>
      </div>

      {/* Transactions Table / Cards */}
      {filteredTransactions.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 space-y-3">
          <Receipt className="w-12 h-12 text-stone-300 mx-auto" />
          <h3 className="font-bold text-stone-700 text-base">لا توجد حركات مالية مسجلة بعد</h3>
          <p className="text-xs text-stone-400">
            عند تأكيد أي طلب، سيتم تسجيل قيد محاسبي برقم سند ورقم طلب يمكنك مراجعته وطباعته هنا.
          </p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs md:text-sm">
              <thead className="bg-stone-50 border-b border-stone-200 text-stone-600 font-bold">
                <tr>
                  <th className="p-4">رقم المعاملة (السند)</th>
                  <th className="p-4">رقم الطلب</th>
                  <th className="p-4">التاريخ والوقت</th>
                  <th className="p-4">وسيلة الدفع</th>
                  <th className="p-4">المبلغ المستحق</th>
                  <th className="p-4">الحالة</th>
                  <th className="p-4 text-center">إيصال</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filteredTransactions.map(tx => (
                  <tr key={tx.id} className="hover:bg-stone-50 transition">
                    <td className="p-4 font-mono font-bold text-stone-800">
                      {tx.transactionNumber}
                    </td>
                    <td className="p-4 font-bold text-emerald-800">
                      {tx.orderNumber ? `#${tx.orderNumber}` : 'تسوية حساب'}
                    </td>
                    <td className="p-4 text-stone-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-stone-400" />
                        <span>{new Date(tx.date).toLocaleDateString('ar-EG')}</span>
                        <span className="text-[11px] text-stone-400">
                          {new Date(tx.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </td>
                    <td className="p-4">{getMethodBadge(tx.paymentMethod)}</td>
                    <td className="p-4">
                      <span className="font-black text-stone-900 text-sm md:text-base">
                        {tx.amount} جنيه
                      </span>
                    </td>
                    <td className="p-4">
                      {tx.status === 'completed' ? (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-md">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>مسدد ومكتمل</span>
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
                          <Clock className="w-3 h-3" />
                          <span>قيد التحصيل (عند الاستلام)</span>
                        </span>
                      )}
                    </td>
                    <td className="p-4 text-center">
                      <button
                        onClick={() => setSelectedTx(tx)}
                        className="px-3 py-1 bg-stone-100 hover:bg-emerald-50 hover:text-emerald-700 text-stone-700 rounded-lg text-xs font-semibold transition"
                      >
                        عرض السند
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Invoice / Receipt Modal */}
      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl border border-stone-200">
            <div className="text-center pb-4 border-b border-stone-200 space-y-1">
              <span className="text-xs bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full font-bold">
                سند قيد مالي معتمد
              </span>
              <h3 className="text-xl font-black text-stone-900 mt-2">متجر بلدي - أحلى بقالة</h3>
              <p className="text-xs text-stone-400">سند رقم: {selectedTx.transactionNumber}</p>
            </div>

            <div className="space-y-2.5 text-xs text-stone-700">
              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-500">اسم العميل:</span>
                <span className="font-bold">{selectedTx.userName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-500">رقم الطلب المرتبط:</span>
                <span className="font-bold text-emerald-700">#{selectedTx.orderNumber}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-500">طريقة الدفع:</span>
                <span>{getMethodBadge(selectedTx.paymentMethod)}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-500">تاريخ القيد:</span>
                <span>{new Date(selectedTx.date).toLocaleString('ar-EG')}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-stone-100">
                <span className="text-stone-500">البيان:</span>
                <span className="text-stone-800">{selectedTx.description}</span>
              </div>
              <div className="flex justify-between py-2 text-sm font-black text-stone-900 bg-stone-50 p-2 rounded-xl">
                <span>المبلغ الإجمالي المسدد:</span>
                <span className="text-emerald-700 text-base">{selectedTx.amount} جنيه</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-stone-800 hover:bg-stone-900 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة السند</span>
              </button>
              <button
                onClick={() => setSelectedTx(null)}
                className="px-5 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition cursor-pointer"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
