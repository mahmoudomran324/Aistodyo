import React from 'react';
import { useStore } from '../context/StoreContext';
import {
  ShieldCheck,
  Phone,
  Store,
  Heart,
  RotateCcw,
  Clock,
  Sparkles
} from 'lucide-react';

interface FooterProps {
  onOpenTerms: () => void;
  onNavigate: (view: 'store' | 'merchant' | 'admin' | 'captain' | 'orders' | 'financials') => void;
  onOpenAuth: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenTerms, onNavigate, onOpenAuth }) => {
  const { settings, currentUser } = useStore();

  return (
    <footer className="bg-stone-900 text-stone-300 pt-12 pb-8 border-t border-stone-800 mt-16">
      <div className="max-w-7xl mx-auto px-4 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Store Brand */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shadow-md">
                ب
              </div>
              <span className="text-xl font-black text-white">{settings.storeName}</span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              {settings.storeSubtitle}. نوفر أجود المحاصيل الزراعية البلدي والمنتجات الطبيعية من الفلاح للبيت مباشرة مع ضمان استرجاع مجاني 100%.
            </p>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-bold">
              <Sparkles className="w-4 h-4" />
              <span>فرز أول - قطفة طازجة يومية</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3 text-xs">
            <h4 className="font-black text-white text-sm">أقسام المتجر</h4>
            <ul className="space-y-2 text-stone-400">
              <li>
                <button onClick={() => onNavigate('store')} className="hover:text-emerald-400 transition">
                  خضروات بلدي طازجة
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('store')} className="hover:text-emerald-400 transition">
                  فواكه موسمية سكرية
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('store')} className="hover:text-emerald-400 transition">
                  بقوليات وجبن بلدي فلاحي
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('store')} className="hover:text-emerald-400 transition">
                  منتجات مجففة وعطارة صعيدي
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Customer Care & Quality */}
          <div className="space-y-3 text-xs">
            <h4 className="font-black text-white text-sm">ميثاق الجودة والأمان</h4>
            <ul className="space-y-2 text-stone-400">
              <li>
                <button
                  onClick={onOpenTerms}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>الشروط وميثاق الجودة الذهبي</span>
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenTerms}
                  className="hover:text-emerald-400 transition flex items-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4 text-emerald-400" />
                  <span>سياسة الاسترجاع المجاني الفوري</span>
                </button>
              </li>
              <li>
                <a
                  href={`https://wa.me/${settings.supportWhatsApp.replace(/\+/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-green-400 transition flex items-center gap-1.5"
                >
                  <Phone className="w-4 h-4 text-green-400" />
                  <span>خدمة عملاء وواتساب المتجر</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Portals Access */}
          <div className="space-y-3 text-xs">
            <h4 className="font-black text-white text-sm">بوابات المتجر</h4>
            <div className="space-y-2">
              <button
                onClick={() => {
                  if (currentUser?.role === 'admin' || currentUser?.role === 'supervisor') {
                    onNavigate('admin');
                  } else {
                    onOpenAuth();
                  }
                }}
                className="w-full text-right py-2 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 transition font-bold"
              >
                بوابة الإدارة والمشرفين
              </button>

              <button
                onClick={() => {
                  if (currentUser?.role === 'trader') {
                    onNavigate('merchant');
                  } else {
                    onOpenAuth();
                  }
                }}
                className="w-full text-right py-2 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 transition font-bold"
              >
                بوابة التجار والمزارع
              </button>

              {settings.isCaptainSystemEnabled && (
                <button
                  onClick={() => onNavigate('captain')}
                  className="w-full text-right py-2 px-3 rounded-xl bg-blue-950/60 hover:bg-blue-900 text-blue-200 transition font-bold"
                >
                  بوابة الكباتن والمناديب 🛵
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 border-t border-stone-800 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <p>© {new Date().getFullYear()} {settings.storeName}. جميع الحقوق محفوظة لخير المزارع المصرية.</p>
          <div className="flex items-center gap-1">
            <span>تم التطوير بأعلى معايير الأداء والسرعة</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" />
          </div>
        </div>
      </div>
    </footer>
  );
};
