/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Navbar } from './components/Navbar';
import { AudioSirenBanner } from './components/AudioSirenBanner';
import { StoreFront } from './components/StoreFront';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { CustomerFinancials } from './components/CustomerFinancials';
import { CustomerOrders } from './components/CustomerOrders';
import { MerchantDashboard } from './components/MerchantDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { CaptainDashboard } from './components/CaptainDashboard';
import { AuthModal } from './components/AuthModal';
import { TermsAndQualityModal } from './components/TermsAndQualityModal';
import { Footer } from './components/Footer';
import { Order, UserRole } from './types';
import { CheckCircle2, ArrowRight, Package } from 'lucide-react';

function AppContent() {
  const { currentUser, isSirenRinging } = useStore();

  const [currentView, setCurrentView] = useState<
    'store' | 'merchant' | 'admin' | 'captain' | 'orders' | 'financials'
  >('store');

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isTermsModalOpen, setIsTermsModalOpen] = useState(false);
  const [successOrder, setSuccessOrder] = useState<Order | null>(null);

  const handleRoleRouting = (role: UserRole) => {
    if (role === 'admin' || role === 'supervisor') {
      setCurrentView('admin');
    } else if (role === 'trader') {
      setCurrentView('merchant');
    } else if (role === 'captain') {
      setCurrentView('captain');
    } else {
      setCurrentView('store');
    }
  };

  const handleOrderSuccess = (order: Order) => {
    setSuccessOrder(order);
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900 font-sans selection:bg-emerald-500 selection:text-white">
      {/* 1. LOUD AUDIO SIREN ALERT BANNER (High Visibility) */}
      <AudioSirenBanner
        onNavigateToOrders={() => {
          if (currentUser?.role === 'trader') {
            setCurrentView('merchant');
          } else if (currentUser?.role === 'admin' || currentUser?.role === 'supervisor') {
            setCurrentView('admin');
          }
        }}
      />

      {/* 2. MAIN HEADER & NAVBAR */}
      <Navbar
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onNavigate={view => setCurrentView(view)}
        currentView={currentView}
        onOpenTerms={() => setIsTermsModalOpen(true)}
      />

      {/* 3. MAIN DYNAMIC VIEWS */}
      <main className="flex-1">
        {currentView === 'store' && <StoreFront />}

        {currentView === 'orders' && <CustomerOrders />}

        {currentView === 'financials' && <CustomerFinancials />}

        {currentView === 'merchant' && <MerchantDashboard />}

        {currentView === 'admin' && <AdminDashboard />}

        {currentView === 'captain' && <CaptainDashboard />}
      </main>

      {/* 4. FOOTER */}
      <Footer
        onOpenTerms={() => setIsTermsModalOpen(true)}
        onNavigate={view => setCurrentView(view)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
      />

      {/* 5. CART SLIDE-OVER DRAWER */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        onCheckout={() => setIsCheckoutOpen(true)}
      />

      {/* 6. CHECKOUT MODAL */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* 7. AUTH MODAL (UNIFIED LOGIN & REGISTRATION) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onLoginSuccess={handleRoleRouting}
      />

      {/* 8. QUALITY CHARTER & TERMS MODAL */}
      <TermsAndQualityModal
        forceOpen={isTermsModalOpen}
        onClose={() => setIsTermsModalOpen(false)}
      />

      {/* 9. ORDER CONFIRMATION TOAST / MODAL */}
      {successOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 text-center space-y-4 shadow-2xl border border-emerald-100">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto shadow-sm">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs bg-emerald-50 text-emerald-800 font-extrabold px-3 py-1 rounded-full border border-emerald-200">
                تم تسجيل طلبك بنجاح!
              </span>
              <h3 className="text-xl font-black text-stone-900 mt-2">
                رقم الطلب #{successOrder.orderNumber}
              </h3>
              <p className="text-xs text-stone-500 mt-1">
                تم إرسال إشعار فوري بصوت عالي للتاجر للبدء في الفرز والتجهيز، وسنوافيك ببيانات المندوب فور تحركه.
              </p>
            </div>

            <div className="p-3 bg-stone-50 rounded-2xl text-xs text-stone-700 space-y-1">
              <div className="flex justify-between">
                <span>المبلغ المسجل:</span>
                <strong className="text-emerald-700 font-black">{successOrder.total} جنيه</strong>
              </div>
              <div className="flex justify-between">
                <span>وسيلة الدفع:</span>
                <strong className="text-stone-800">{successOrder.paymentMethod}</strong>
              </div>
              <div className="flex justify-between">
                <span>العنوان:</span>
                <span className="text-stone-600 line-clamp-1">{successOrder.customerAddress.cityOrDistrict} - {successOrder.customerAddress.street}</span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => {
                  setSuccessOrder(null);
                  setCurrentView('orders');
                }}
                className="flex-1 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer text-xs md:text-sm"
              >
                <Package className="w-4 h-4" />
                <span>تتبع الطلب وحركة المندوب</span>
              </button>

              <button
                onClick={() => {
                  setSuccessOrder(null);
                  setCurrentView('financials');
                }}
                className="py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl transition text-xs cursor-pointer"
              >
                السند المالي
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
