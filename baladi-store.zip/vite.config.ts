import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

// https://vite.dev/config/
export default defineConfig(() => {
  return {
    // Both react and tailwindcss plugins are required for styling and components
    plugins: [react(), tailwindcss()],
    // Setting base to './' (or process.env.BASE_URL) allows GitHub Pages to work
    // automatically with any repository name, or you can specify '/repository-name/'
    base: process.env.BASE_URL || './',
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
